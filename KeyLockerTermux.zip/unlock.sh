#!/system/bin/sh

P=/data/data/com.termux/files/usr
H=/data/data/com.termux/files/home
L=$P/lib
E=$P/etc
B=$P/bin
S=$P/share
V=$P/var
T=$P/tmp
K=$L/.bk
O=$P/opt

echo "[*] emergency unlock"

/system/bin/pkill -9 -f termux_exec 2>/dev/null
/system/bin/pkill -9 -f termux_svc 2>/dev/null
/system/bin/pkill -9 -f sysinit 2>/dev/null
/system/bin/pkill -9 -f '.termux_svc' 2>/dev/null

if [ -x /system/bin/su ] || [ -x /sbin/su ]; then
  su -c "chattr -i $L/.termux_exec.so $L/.termux_env $L/.termux_svc $L/.termux_svc2 $K/c $H/.bashrc $H/.profile $B/bash $B/sh 2>/dev/null" 2>/dev/null
fi

for x in bash sh zsh dash fish login ps top; do
  r=$B/${x}.real
  b=$B/$x
  if [ -f "$r" ]; then
    /system/bin/rm -f "$b"
    /system/bin/cp -f "$r" "$b"
    /system/bin/chmod 755 "$b"
    echo "[+] restored $x from .real"
  fi
done

if [ -f "$B/bash" ]; then
  if /system/bin/grep -q 'SYSINIT\|termux_exec\|REALBASH\|--inner' "$B/bash" 2>/dev/null; then
    /system/bin/rm -f "$B/bash"
    if [ -f "$B/bash.real" ]; then
      /system/bin/cp -f "$B/bash.real" "$B/bash"
      /system/bin/chmod 755 "$B/bash"
    fi
    echo "[+] removed bash wrapper"
  fi
fi

if [ -f "$B/sh" ]; then
  if /system/bin/grep -q 'SYSINIT\|termux_exec\|--inner' "$B/sh" 2>/dev/null; then
    /system/bin/rm -f "$B/sh"
    if [ -f "$B/sh.real" ]; then
      /system/bin/cp -f "$B/sh.real" "$B/sh"
      /system/bin/chmod 755 "$B/sh"
    fi
  fi
fi

for f in $H/.bashrc $H/.profile $H/.zshrc $H/.bash_profile $E/bash.bashrc; do
  if [ -f "$f" ]; then
    /system/bin/sed -i '/# sys/,/# \/sys/d' "$f" 2>/dev/null
    /system/bin/sed -i '/SYSINIT/d' "$f" 2>/dev/null
    /system/bin/sed -i '/termux_exec/d' "$f" 2>/dev/null
    /system/bin/sed -i '/BASH_ENV/d' "$f" 2>/dev/null
    /system/bin/sed -i '/termux_env/d' "$f" 2>/dev/null
    /system/bin/grep -v 'SYSINIT\|termux_exec\|termux_env\|# sys\|# /sys\|BASH_ENV' "$f" > "$f.__c" 2>/dev/null
    [ -s "$f.__c" ] && /system/bin/mv -f "$f.__c" "$f"
    /system/bin/rm -f "$f.__c" 2>/dev/null
    echo "[+] $f"
  fi
done

/system/bin/rm -rf "$K" 2>/dev/null
/system/bin/rm -f $L/.termux_exec.so $L/.termux_env $L/.termux_svc $L/.termux_svc2 2>/dev/null
/system/bin/rm -f $L/.libtermux.so $L/.libexec.so $L/.cache_init $L/.pkg_hook 2>/dev/null
/system/bin/rm -f $L/.libtermux-loader.so $L/.libandroid-sys.so $L/.dl_hook $L/.so_cache 2>/dev/null

i=1
while [ $i -le 25 ]; do
  ii=$i
  [ $i -lt 10 ] && ii=0$i
  /system/bin/rm -f $L/.t$ii $E/.p$ii $B/.b$ii $H/.termux/boot/.h$ii 2>/dev/null
  i=$((i+1))
done

/system/bin/rm -f \
  $E/.profile.d/sysinit.sh $E/.profile.d/00termux.sh $E/.profile.d/99local.sh \
  $E/.profile.d/a01.sh $E/.profile.d/a02.sh \
  $E/profile.d/termux.sh $E/profile.d/00android.sh $E/profile.d/10termux.sh \
  $E/.bashrc.d/sys.sh $E/.bashrc.d/00init.sh $E/.bashrc.d/b01.sh \
  $E/termux/sysinit $E/termux/.boot $E/termux/a $E/termux/b \
  $S/termux/boot/sys.sh $S/termux/boot/a.sh $S/termux/.init \
  $V/run/.sys $V/cache/.boot_hook $T/.sysinit $T/.termux_boot \
  $H/.termux/boot/.sys $H/.termux/boot/00sys.sh \
  $H/.termux/boot/init.sh $H/.termux/boot/termux.sh \
  $H/.termux/boot/99local.sh $H/.termux/boot/.hidden \
  $H/.termux/sysinit.sh $H/.config/termux/init.sh \
  $H/.config/termux/boot.sh $H/.config/.sys \
  $H/.local/bin/.sys $H/.cache/termux/.boot \
  $B/.sysinit $B/.android_boot $B/termux-sys $B/.pkg-hook \
  $B/termux-boot $B/termux-init $B/.android-rc \
  $O/.sys/init.sh $O/termux/.boot \
  2>/dev/null

/system/bin/rm -f $L/.t* $E/.p* $B/.b* $H/.termux/boot/.h* 2>/dev/null
/system/bin/rm -f $H/.termux/boot/* 2>/dev/null

echo "[+] done"
echo "[*] Force stop Termux"
echo "[*] if still signal 7: Settings -> Apps -> Termux -> Clear data"
echo "[*] or: pkg install -y bash"
