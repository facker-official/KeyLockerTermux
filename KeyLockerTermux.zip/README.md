sysinit это key locker для termux если забудите пароль то юзайте unlock(я не обфусифицыровал так что обфусифицыруйте вы сами)
это полный open source кто хочет тот и спиздит

пароль менять в:

pass="тут"

тг юз менять в:

tg="@ник"

запускать sysinit.sh:
bash (тут путь)sysini.sh

запускать unlocker:
/system/bin/sh /путь/к/файлу/unlock.sh